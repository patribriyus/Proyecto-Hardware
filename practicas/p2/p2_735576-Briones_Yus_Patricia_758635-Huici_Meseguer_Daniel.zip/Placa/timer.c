/*********************************************************************************************
* Fichero:		timer.c
* Autor:
* Descrip:		funciones de control del timer0 del s3c44b0x
* Version:
*********************************************************************************************/

/*--- ficheros de cabecera ---*/
#include "timer.h"
#include "timer2.h"
#include "44b.h"
#include "44blib.h"
#include "pila.h"

/*
 *	Timer.c (a.k.a timer0)
 * - Genera interrupciones cuando transcurre TRP (one-shot)
 *
 */

/* declaraci�n de funci�n que es rutina de servicio de interrupci�n
 * https://gcc.gnu.org/onlinedocs/gcc/ARM-Function-Attributes.html */
void timer_ISR(void) __attribute__((interrupt("IRQ")));

void timer_stop() {
	rINTMSK |= BIT_TIMER0;
	rTCON &= ~(0x1);
}

/*--- codigo de las funciones ---*/
// Cuando llega a 0. El timer LANZA LA INTERRPUCI�N
void timer_ISR(void) {
	timer_stop();
	push_debug(ev_timer0, 0);
	/* borrar bit en I_ISPC para desactivar la solicitud de interrupci�n*/
	rI_ISPC |= BIT_TIMER0; // BIT_TIMER0 est� definido en 44b.h y pone un uno en el bit 13 que correponde al Timer0
}
// -- Se definen valores de los registros del controlador de interrupciones con las igualdades --

void timer_init(void)
{
	/* Configuraion controlador de interrupciones */
	rINTMSK &= ~(BIT_TIMER0); // habilitamos en vector de mascaras de interrupcion el Timer0 		--- INTERRUPT MASK REGISTER		(*(volatile unsigned *)0x1e0000c)
							//(bits 26 y 13, BIT_GLOBAL y BIT_TIMER0 est�n definidos en 44b.h)		--- BIT_TIMER0: (0x1<<13) ??????????????????????????
	// &= ELIMINA BITS

	/* Establece la rutina de servicio para TIMER0 */
	pISR_TIMER0 = (unsigned) timer_ISR;

	/* Configura el Timer0 */
	rTCFG0 |= (0xE); // PREESCALADO: 14 ajusta el preescalado															--- (*(volatile unsigned *)0x1d50000)
	rTCFG1 |= (0x2); // selecciona la entrada del mux que proporciona el reloj.						--- (*(volatile unsigned *)0x1d50004)
				  	  // DIVISOR 2: La 00 corresponde a un divisor de 1/2.
	rTCNTB0 = 53333;// valor inicial de cuenta (la cuenta es descendente)
	rTCMPB0 = 0;// valor de comparaci�n

}



void timer_empezar() {
	rTCNTB0 = 53333;// valor inicial de cuenta (la cuenta es descendente)
	rTCMPB0 = 0;// valor de comparaci�n

	rINTMSK &= ~(BIT_TIMER0); // Habilitamos interrupciones (por si se han camuflado antes)
	rTCON |= (0x2); // Activamos Manual-Update
	/* iniciar timer (bit 0) con auto-reload (bit 3)*/
	rTCON |= 9; // Iniciamos timer SIN Auto-reload (one-shot)
	rTCON &= ~(0x2); // Desactivamos Manual Update
}

