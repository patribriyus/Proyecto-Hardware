#include "botones_antirebotes.h"
#include "timer.h"
#include "timer2.h"
#include "pila.h"
#include "button.h"
#include "stdio.h"

/*--------------------------------------------------------------*/

static volatile enum evento estado_actual;
static volatile enum estado_button boton_actual;

static enum estado_button atendiendo_boton = button_none;

void botones_antirebotes_init(void)
{
    estado_actual = EST_INICIO;
    boton_actual = button_none;
}

void boton_pulsado(enum estado_button boton_presionado) {
    estado_actual = EST_REBOTES_PRESION;
    boton_actual = boton_presionado;
    atendiendo_boton = boton_presionado;

}

enum estado_button botones_antirebotes_leer(void) {
    return boton_actual;
}

enum estado_button botones_antirebotes_atendido(void) {
    return boton_antirrebotes_atendido;
}

void botones_antirebotes_set(enum estado_button boton_recibido) {
	boton_antirrebotes_atendido = boton_recibido;
}

void botones_antirebotes_gestion() {
    switch (estado_actual) {
    	case EST_INICIO: break;

		case EST_REBOTES_PRESION: {// Espera el tiempo TRP
				estado_actual = EST_MANTIENE_PULSADO;
				timer3_empezar(); // Inicio timer de espera 30ms
			break;
		}
		case EST_MANTIENE_PULSADO: { // Espera de 30ms pa ver si ha sido depresionado
			enum estado_button estado_boton_nuevo = button_estado();
			if (estado_boton_nuevo != boton_actual) { // Si ya se ha depresionado
				boton_actual = estado_boton_nuevo;
				estado_actual = EST_REBOTES_DEPRESION;
				timer4_empezar();
			} else {
				timer3_empezar();
				estado_actual = EST_MANTIENE_PULSADO;
			}
			break;
		}
		case EST_REBOTES_DEPRESION: { // Espera el tiempo TRD y habilita interrupciones

			boton_antirrebotes_atendido = atendiendo_boton;
			button_resetear(); // Habilita de nuevo las interrupciones para bot�n
			push_debug(button_ok, 0);
			estado_actual = EST_INICIO;
			break;
		}

	}

}

