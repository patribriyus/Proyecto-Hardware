#ifndef _JUGADA_H_
#define _JUGADA_H_

void jugada_por_botones(uint8_t* fila, uint8_t* columna, uint8_t* ready);
void jugada_init();

#endif
