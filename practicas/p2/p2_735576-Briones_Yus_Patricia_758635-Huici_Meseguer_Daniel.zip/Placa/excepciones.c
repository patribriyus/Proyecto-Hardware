/*********************************************************************************************
* Fichero:		excepciones.c
* Autor:
* Descrip:		funciones de control del timer0 del s3c44b0x
* Version:
*********************************************************************************************/

/*--- Ficheros de cabecera ---*/

#include <stdint.h>
#include "44b.h"
#include "44blib.h"

#define INIT 0x0
#define SWI 0x13
#define ABT 0x17
#define UND 0x1B

#define SWI_8LED 1
#define ABT_8LED 2
#define UND_8LED 3
#define BLANK_8LED 16

volatile int DELAY_MS = 50000;
volatile int t0 = 0;
volatile int encendido = 0;
// VARIABLES GLOBALES
static volatile uint32_t interrupcion;
static volatile uint32_t direccion_excepcion; // Direcci�n de la instrucci�n que causa la excepci�n.


void tratamiento_exc(void);

void definir_rutinas(void) {
    pISR_UNDEF 	= (unsigned)tratamiento_exc; // Unsigned!!??
    pISR_SWI 	= (unsigned)tratamiento_exc;
    pISR_DABORT = (unsigned)tratamiento_exc;
}

void tratamiento_exc(void) {
	int n_led;
    __asm__ volatile("mrs %0, cpsr\n\t"
                     "and %0, %0, #0x1F"
                     : "+r"(interrupcion)); // R: La variable reside en un registro
    										// +: See lee y modifica

    __asm__ volatile("mov %0, lr"
                     : "=r"(direccion_excepcion)); // = Sobreescribe el valor

    // http://infocenter.arm.com/help/index.jsp?topic=/com.arm.doc.ddi0311d/I30195.html
    if (interrupcion == SWI) {
    	direccion_excepcion -= 4;
    	n_led = SWI_8LED;
    } else if (interrupcion == ABT) {
    	direccion_excepcion -= 8;
    	n_led = ABT_8LED;
    } else if (interrupcion == UND) {
    	direccion_excepcion -= 4;
    	n_led = UND_8LED;
    } else { // Debug
    	 while(1);
    }
   // t0 = timer2_leer();
    while (1) {
    	D8Led_symbol(n_led);
		Delay(50000);
    	D8Led_symbol(BLANK_8LED);
    	Delay(50000);
    }
}
