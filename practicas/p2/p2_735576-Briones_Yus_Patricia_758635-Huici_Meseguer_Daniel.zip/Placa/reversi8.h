/*********************************************************************************************
* Fichero:		reversi8.h

* Autor:
* Descrip:		funciones de acceso para reversi8_2019.c
* Version:
*********************************************************************************************/

#ifndef _REVERSI8_H_
#define _REVERSI8_H_


/*--- declaracion de funciones visibles del módulo reversi8_2019.c/reversi8_2019.h ---*/
void reversi8_main();


#endif /* _REVERSI8_H_ */
