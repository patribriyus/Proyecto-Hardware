#ifndef _LATIDO_H_
#define _LATIDO_H_

#include "stdint.h"

void Latido_ev_new_tick(void);

#endif
