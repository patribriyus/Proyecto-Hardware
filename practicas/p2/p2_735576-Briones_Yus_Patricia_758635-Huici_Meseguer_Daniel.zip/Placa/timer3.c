/*********************************************************************************************
* Fichero:		timer3.c
* Autor:
* Descrip:		funciones de control del timer3 del s3c44b0x
* Version:
*********************************************************************************************/

/*--- ficheros de cabecera ---*/
#include "timer3.h"
#include "44b.h"
#include "44blib.h"
#include "pila.h"


/*
 * Timer3.c
 *
 * Lanza interrupciones cuando ha transcurrido 30ms
 *
 *
 */

/* declaraci�n de funci�n que es rutina de servicio de interrupci�n
 * https://gcc.gnu.org/onlinedocs/gcc/ARM-Function-Attributes.html */
void timer3_ISR(void) __attribute__((interrupt("IRQ")));

void timer3_stop() {
	rINTMSK |= BIT_TIMER3; // Enmascaramos interrupciones
	rTCON &= ~(0x10000); // Paramos el timer3
}

/*--- codigo de las funciones ---*/
void timer3_ISR(void)
{
	timer3_stop();
	push_debug(ev_timer3, 0);
	/* borrar bit en I_ISPC para desactivar la solicitud de interrupci�n*/
	rI_ISPC |= BIT_TIMER3; // BIT_TIMER3 est� definido en 44b.h y pone un uno en el bit 13 que correponde al Timer5
}
// -- Se definen valores de los registros del controlador de interrupciones con las igualdades --

void timer3_init(void)
{
	/* Configuraion controlador de interrupciones */
	rINTMSK &= ~(BIT_TIMER3); // habilitamos en vector de mascaras de interrupcion el Timer0 		--- INTERRUPT MASK REGISTER		(*(volatile unsigned *)0x1e0000c)
							//(bits 26 y 13, BIT_GLOBAL y BIT_TIMER0 est�n definidos en 44b.h)		--- BIT_TIMER0: (0x1<<13) ??????????????????????????
	/* Establece la rutina de servicio para TIMER0 */
	pISR_TIMER3 = (unsigned) timer3_ISR;

	/* Configura el Timer3 */
	rTCFG0 |= (0x0); // PREESCALADO: ajusta el preescalado. Comparte con timer3				--- (*(volatile unsigned *)0x1d50000)
	rTCFG1 |= (0x4000); // selecciona la entrada del mux que proporciona el reloj.						--- (*(volatile unsigned *)0x1d50004)
				  	    // DIVISOR 32
	rTCNTB3 = 60000;// valor inicial de cuenta (la cuenta es descendente)
	rTCMPB3 = 0;// valor de comparaci�n

}



void timer3_empezar() {
	rTCNTB3 = 60000;// valor inicial de cuenta (la cuenta es descendente)
	rTCMPB3 = 0;// valor de comparaci�n

	rINTMSK &= ~(BIT_TIMER3); // Habilitamos las interrupciones
	rTCON |= 0x20000; // Activamos el MANUAL-UPDATE
	rTCON |= 0x90000; // Iniciamos timer CON AUTORELOAD
	rTCON &= ~(0x20000); // Desactivaoms el MANUAL-UPDATE
}

